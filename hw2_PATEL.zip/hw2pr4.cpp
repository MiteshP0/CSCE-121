//Mitesh
//CSCE 121 - 507
//Due: February 10, 2015
//hw2pr4.cpp

/* This program will calculate the phase of the moon (day of
the lunar month) from a given month, day, and year, using the formulae
referenced in the Wikipedia articles on "Lunar Phase" and "Julian Day." */

#include "std_lib_facilities_4a.h"

int main()
{
    int Y;
    int M;
    int D;
    //variables for julian day
    int A;
    int B;
    int C;
    int E;
    int F;
    int Julian_Day;
    const double Julian_Day_Jan1st1990 = 2415021.0;
    const double days_full_moon = 29.53055;
    
    string again; // string for end of do while loop to ask user y or n
    do
    {
        try
        {
            cout << "Month(1-12)? ";
            cin >> M;
            cout << "Day? ";
            cin >> D;
            cout << "Year? ";
            cin >> Y;
            if(M < 0 || D< 0 || Y < 0)
                throw runtime_error("Error. Invalid input "); // throw error
        }
        catch(runtime_error&e) // catch exception
        {
            cerr << "Error: " << e.what();
            exit(0); // exit program after error
        }
    // if month is january or feburary then subtract one to the year and add 12 to the month to calculate julian day number. // Juluan day calculations from http://quasar.as.utexas.edu/BillInfo/JulianDatesG.html
    
        if (M == 1 || M == 2)
        {
            Y -= 1;
            M += 12;
        }
        A = Y/100;
        B = A/4;
        C = 2-A+B;
        E = 365.25*(Y+4716);
        F = 30.6001*(M+1);
        Julian_Day = C+D+E+F-1524.5;
    
    //using fmod to produce output as double like in example
        cout << "It has been approximetly " << fmod(++Julian_Day - Julian_Day_Jan1st1990 , days_full_moon)<<" days since the new moon.\n";
        
        cout << "Want to try another date? (y or n)\n";
        cin >> again;
    
    } while(again == "y" || again =="Y");
    
    

    
    
    return 0;
}


