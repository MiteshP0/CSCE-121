// Mitesh Patel
// CSCE 121 - 507
// Due: February 10, 2015
//hw2pr1.cpp


#include "std_lib_facilities_4a.h"


	void check_conditions();
	//global variable and vector for use with function
	int number;
	vector<string> word {"cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "seite", "ocho", "nueve", "diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve" }; 
int main()
{
	while(1)
	{
    
        try
        {
            cout <<"Enter number from 0-19 in digit form ";
            cin >> number;
            check_conditions();
            if (number < 0)
                throw runtime_error("I do not accept negative values please enter positive number from 0-20!\n");
        }
        catch (runtime_error& e)
        {
            cerr << "error: " << e.what();
        }
	}
	

    
    return 0;
}

void check_conditions()
{
	if(number == 0)
    {
            cout <<"In Spanish that is " << word[0]<<".\n";
    
    }
    else if(number == 1)
    {
        cout <<"In Spanish that is " << word[1]<<".\n";
        
    }
    else if(number == 2)
    {
        cout <<"In Spanish that is " << word[2]<<".\n";
        
    }
    else if(number == 3)
    {
        cout <<"In Spanish that is " << word[3]<<".\n";
        
    }
    else if(number == 4)
    {
        cout <<"In Spanish that is " << word[4]<<".\n";
        
    }
    else if(number == 5)
    {
        cout <<"In Spanish that is " << word[5]<<".\n";
        
    }
    else if(number == 6)
    {
        cout <<"In Spanish that is " << word[6]<<".\n";
        
    }
    else if(number == 7)
    {
        cout <<"In Spanish that is " << word[7]<<".\n";
        
    }
    else if(number == 8)
    {
        cout <<"In Spanish that is " << word[8]<<".\n";
        
    }
    else if(number == 9)
    {
        cout <<"In Spanish that is " << word[9]<<".\n";
        
    }
    else if(number == 10)
    {
        cout <<"In Spanish that is " << word[10]<<".\n";
        
    }
    else if(number == 11)
    {
        cout <<"In Spanish that is " << word[11]<<".\n";
        
    }
    else if(number == 12)
    {
        cout <<"In Spanish that is " << word[12]<<".\n";
        
    }
    else if(number == 13)
    {
        cout <<"In Spanish that is " << word[13]<<".\n";
        
    }
    else if(number == 14)
    {
        cout <<"In Spanish that is " << word[14]<<".\n";
        
    }
    else if(number == 15)
    {
        cout <<"In Spanish that is " << word[15]<<".\n";
        
    }
    else if(number == 16)
    {
        cout <<"In Spanish that is " << word[16]<<".\n";
        
    }
    else if(number == 17)
    {
        cout <<"In Spanish that is " << word[17]<<".\n";
        
    }
    else if(number == 18)
    {
        cout <<"In Spanish that is " << word[18]<<".\n";;
        
    }
    else if(number == 19)
    {
        cout <<"In Spanish that is " << word[19]<<".\n";
        
    }
    else
    {
        cout << "Sorry, my vocabulary does not include " << number << " My vocabulary is limited to 0-19 only!\n";
    }

} 
