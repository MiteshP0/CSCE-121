π//Mitesh
//CSCE 121 - 507
//Due: February 10, 2015
//hw2pr2.cpp

#include "std_lib_facilities_4a.h"

// This program is a guessing game called "Bulls and Cows"

int main()
{
    // vector for holding individual digits of correct number hard coded below and guessed number inputted by user
    vector<int> guessed_digit;
    vector<int> correct_digit;
    int correct_number = 1234; // hard coded number
    int first_correct_digit = correct_number / 1000;
    int second_correct_digit = correct_number / 100 % 10;
    int third_correct_digit = correct_number / 10 % 10;
    int fourth_correct_digit = correct_number % 10;
    //pushes back each digit into the vector
    correct_digit.push_back(first_correct_digit); // correct_digit[0]
    correct_digit.push_back(second_correct_digit); // correct_digit[1]
    correct_digit.push_back(third_correct_digit); // correct_digit[2]
    correct_digit.push_back(fourth_correct_digit); // correct_digit[3]
    // to hold the number of bulls and cows in a variable
    int bulls;
    int cows;
    
    
    string guess_again; // string located outside do while loop because of scope
    do
    {
        try // start of try block
        {
            cout << "Guess the 4 digit number.\n";
            int guess_number;
            cin >> guess_number;
            
            if(guess_number < 0)
            {
                throw runtime_error("Please enter a positive 4 digit number!"); // throw exception
            }
        
            bulls = 0;
            cows = 0;
            guessed_digit.clear(); // clear vector in case user wants to guess again
            guessed_digit.push_back(guess_number / 1000); // guessed_digit[0]
            guessed_digit.push_back(guess_number / 100 % 10); // guessed_digit[1]
            guessed_digit.push_back(guess_number / 10 % 10); // guessed_digit[2]
            guessed_digit.push_back(guess_number % 10); // guessed_digit[3]
        
            for(int i = 0; i<=3; ++i)
            {
                if(guessed_digit[i] == correct_digit[i])
                    ++bulls;

            }
            
            // conditions to find out how many cows
            if(guessed_digit[0] == correct_digit[1])
                ++cows;
            if(guessed_digit[0] == correct_digit[2])
                ++cows;
            if(guessed_digit[0] == correct_digit[3])
                ++cows;
            if(guessed_digit[1] == correct_digit[0])
                ++cows;
            if(guessed_digit[1] == correct_digit[2])
                ++cows;
            if(guessed_digit[1] == correct_digit[3])
                ++cows;
            if(guessed_digit[2] == correct_digit[0])
                ++cows;
            if(guessed_digit[2] == correct_digit[1])
                ++cows;
            if(guessed_digit[2] == correct_digit[3])
                ++cows;
            if(guessed_digit[3] == correct_digit[0])
                ++cows;
            if(guessed_digit[3] == correct_digit[1])
                ++cows;
            if(guessed_digit[3] == correct_digit[2])
                ++cows;
            
        
            cout << bulls << " bulls " << cows <<" cows.\n";
            if(bulls == 4)
            {
                cout << "Congrats! You have guessed all 4 digits correctly! ... Program Exited \n";
                exit(0);
            
            }
          
        }// end of try block
        catch (runtime_error& e) // catch exception
        {
            cerr <<"error: "<< e.what() << '\n';
        }
        catch(...)
        {
            cerr << "Ooops: unknown exception!\n";
            return 1;
        }
        
        cout << "Want to take another guess?(y or n)\n";
        cin >> guess_again;

    } while(guess_again == "y");
    
    

    return 0;
}
