//Mitesh
//CSCE 121 - 507
//Due: February 10, 2015
//hw2pr3.cpp

#include "std_lib_facilities_4a.h"

// This program is a guessing game called "Bulls and Cows" The random generator will generate a random 4 digit number, and you will have to guess it by using this program.

int main()
{

    vector<int> guessed_digit;
    vector<int> correct_digit;
    int bulls;
    int cows;
    int n;
    cout << "Enter any random number so I can generate a seed. \n"; // asks the user for a number so random number generator can be seeded
    cin >> n;
    seed_randint(n); // n is the seed
    int correct_number = randint(1000,9999); // store random 4 digit number in the variable
    int first_correct_digit = correct_number / 1000;
    int second_correct_digit = correct_number / 100 % 10;
    int third_correct_digit = correct_number / 10 % 10;
    int fourth_correct_digit = correct_number % 10;
    //pushes back each digit into the vector
    correct_digit.clear(); // clear before each new random number is stored
    correct_digit.push_back(first_correct_digit); // correct_digit[0]
    correct_digit.push_back(second_correct_digit); // correct_digit[1]
    correct_digit.push_back(third_correct_digit); // correct_digit[2]
    correct_digit.push_back(fourth_correct_digit); // correct_digit[3]
    // to hold the number of bulls and cows in a variable
    cout << endl; // for spacing
    cout << "NOTE: If random number is 7113, and you guess 5114, then you will recieve 2 bulls and 2 cows because the duplicate 1's will result in 2 cows.\n\n";
    
    string guess_again; // string located outside do while loop because of scope
    do
    {
        try
        {
            cout << "Guess the 4 digit random number I generated.\n";
            int guess_number;
            cin >> guess_number;
            
            if(guess_number < 0)
            {
                throw runtime_error("Please enter a positive 4 digit number!"); // throw exception
            }
        
            bulls = 0;
            cows = 0;
            guessed_digit.clear(); // clear vector in case user wants to guess again
            guessed_digit.push_back(guess_number / 1000); // guessed_digit[0]
            guessed_digit.push_back(guess_number / 100 % 10); // guessed_digit[1]
            guessed_digit.push_back(guess_number / 10 % 10); // guessed_digit[2]
            guessed_digit.push_back(guess_number % 10); // guessed_digit[3]
        
            for(int i = 0; i<=3; ++i)
            {
                if(guessed_digit[i] == correct_digit[i])
                    ++bulls;
            
            }
            // conditions to find out how many cows
            if(guessed_digit[0] == correct_digit[1])
                ++cows;
            if(guessed_digit[0] == correct_digit[2])
                ++cows;
            if(guessed_digit[0] == correct_digit[3])
                ++cows;
            if(guessed_digit[1] == correct_digit[0])
                ++cows;
            if(guessed_digit[1] == correct_digit[2])
                ++cows;
            if(guessed_digit[1] == correct_digit[3])
                ++cows;
            if(guessed_digit[2] == correct_digit[0])
                ++cows;
            if(guessed_digit[2] == correct_digit[1])
                ++cows;
            if(guessed_digit[2] == correct_digit[3])
                ++cows;
            if(guessed_digit[3] == correct_digit[0])
                ++cows;
            if(guessed_digit[3] == correct_digit[1])
                ++cows;
            if(guessed_digit[3] == correct_digit[2])
                ++cows;
        
        
            cout << bulls << " bulls " << cows <<" cows.\n";
            if(bulls == 4)
            {
                cout << "Congrats! You have guessed all 4 digits correctly! ... Program Exited \n";
                exit(0);
            
            }
        
        } // end of try block
        catch (runtime_error& e) // catch exception
        {
            cerr <<"error: "<< e.what() << '\n';
        }
        catch(...)
        {
            cerr << "Ooops: unknown exception!\n";
            return 1;
        }
        
        cout << "Want to take another guess?(y or n)\n";
        cin >> guess_again;
        
    } while(guess_again == "y");
    
    return 0;
}


