// Mitesh Patel
// CSCE 121 - 507
// Due: February 24, 2015
// hw3pr1.cpp

//This program is a calculator with basic functions.
#include "std_lib_facilities.h"

//structure to hold kind and value
struct Token {
    char kind;
    double value;
    string name;
    // different constructors
    Token(char ch) :kind(ch), value(0) { }
    Token(char ch, double val) :kind(ch), value(val) { }
    Token(char ch, string n) : kind(ch), name(n)    { } //need constructor for variable
};

//class to hold token buffer and functions
class Token_stream {
    bool full;
    Token buffer;
public:
    Token_stream() :full(0), buffer(0) { }
    
    Token get(); // get a token
    void unget(Token t) { buffer=t; full=true; } // copy t to buffer and now buffer should be full
    
    void ignore(char);
};

// character constants needed for calculator
const char let = 'L';
const char quit = 'Q';
const char print = ';';
const char number = '8';
const char name = 'a';

// get function
Token Token_stream::get()
{
    if (full) { full=false; return buffer; } //do we already have a token ready? if so remove it from buffer
    char ch;
    cin >> ch;
    switch (ch) {
        case '(':
        case ')':
        case '+':
        case '-':
        case '*':
        case '/':
        case '%':
        case ';':
        case '=':
            return Token(ch); // let each character represent itself
        case '.':
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        {	cin.unget(); // put digit back into input stream
            double val;
            cin >> val; // read a floating point number
            return Token(number,val);
        }
        default:
            if (isalpha(ch)) {
                string s;
                s += ch;
                while(cin.get(ch) && (isalpha(ch) || isdigit(ch))) s+=ch;
                cin.unget();
                if (s == "let") return Token(let);
                if (s == "q") return Token(quit); // return quit to quit calc program
                return Token(name,s);
            }
            error("Bad token");
    }
}


void Token_stream::ignore(char c)
{
    if (full && c==buffer.kind) {
        full = false;
        return;
    }
    full = false;
    
    char ch;
    while (cin>>ch)
        if (ch==c) return;
}

//structure to hold name and value
struct Variable {
    string name;
    double value;
    Variable(string n, double v) :name(n), value(v) { }
};

vector<Variable> names;

// get_value function returns value of variable
double get_value(string s)
{
    for (int i = 0; i<names.size(); ++i)
        if (names[i].name == s) return names[i].value;
    error("get: undefined name ",s);
}

void set_value(string s, double d)
{
    for (int i = 0; i<=names.size(); ++i)
        if (names[i].name == s) {
            names[i].value = d;
            return;
        }
    error("set: undefined name ",s);
}

bool is_declared(string s)
{
    for (int i = 0; i<names.size(); ++i)
        if (names[i].name == s) return true;
    return false;
}

Token_stream ts;

double expression(); // declared in this location so primary and term can have access to it

double primary() //deals with numbers and parentheses
{
    Token t = ts.get(); // get next token from ts
    switch (t.kind) {
        case '(':
        {	double d = expression();
            t = ts.get();
            if (t.kind != ')') error("'(' expected");
        }
        case '-':
            return - primary();
        case number:
            return t.value;
        case name:
            return get_value(t.name);
        default:
            error("primary expected");
    }
}

double term() //deals with * and /
{
    double left = primary(); //read and evaluate a primary
    while(true) {
        Token t = ts.get(); //get next token
        switch(t.kind) {
            case '*':
                left *= primary(); //evaluate left term and multiply
                break;
            case '/':
            {	double d = primary();
                if (d == 0) error("divide by zero");
                left /= d; //evaluate left term and divide
                break;
            }
            default:
                ts.unget(t); //put t back into token stream
                return left; // finally: no more / or *; return the answer
        }
    }
}

double expression() // deals with + and -
{
    double left = term(); // read and evaluate a term
    while(true) {
        Token t = ts.get(); // get next token
        switch(t.kind) {
            case '+':
                left += term(); //evaluate left term and add
                break;
            case '-':
                left -= term(); //evaluate left term and subtract
                break;
            default:
                ts.unget(t); //put t back into token stream
                return left; // finally: no more + or -; return the answer
        }
    }
}

double declaration()
{
    Token t = ts.get(); // get token
    if (t.kind != 'a') error ("name expected in declaration");
    string name = t.name;
    if (is_declared(name)) error(name, " declared twice");
    Token t2 = ts.get(); // get token
    if (t2.kind != '=') error("= missing in declaration of " ,name);
    double d = expression();
    names.push_back(Variable(name,d));
    return d;
}

double statement()
{
    Token t = ts.get(); // get next token
    switch(t.kind) {
        case let:
            return declaration();
        default:
            ts.unget(t); // put back
            return expression();
    }
}

void clean_up_mess()
{
    ts.ignore(print);
}

// > and = used as strings to make code clear
const string prompt = "> ";
const string result = "= ";

void calculate()
{
    while(true) try {
        cout << prompt;
        Token t = ts.get(); // get next token
        while (t.kind == print) t=ts.get();
        if (t.kind == quit) return; //quit
        ts.unget(t); // put back
        cout << result << statement() << endl; // cout result
    }
    catch(runtime_error& e) {
        cerr << e.what() << endl;
        clean_up_mess();
    }
}

int main() // main loop and deal with errors
{
try {
    calculate(); // calls calculate function
    return 0;
}
catch (exception& e) {
    cerr << "exception: " << e.what() << endl; //cout exception
    char c;
    while (cin >>c&& c!=';') ;
    return 1;
    }
    catch (...) {
        cerr << "exception\n";
        char c;
        while (cin>>c && c!=';');
        return 2;
    }
}