// Mitesh Patel
// CSCE 121 - 507
// Due: February 24, 2015
// hw3pr3.cpp

// This programs asks the user for a url of a pdf file, and converts that url into a c-string so it can be viewed as a pdf on build server.http://cms.cse.tamu.edu/academics/undergraduate/fast_track-100603.pdf

#include "std_lib_facilities_4a.h"


int main()
{
    try
    {
        string url;
        cout << "Enter an appropriate URL of a PDF file.\n";
        cin >> url;
        vector<char> vector_URL( url.begin(), url.end() );
        
        //checks ending if pdf or PDF and throws exception if not
        unsigned long int i = vector_URL.size()-3; //v[third to last letter in url. last letter is \n] either begins with P or p if not then dont accept url
        if(vector_URL[i]!= 'p' && vector_URL[i] != 'P' ||
           vector_URL[i+1]!= 'd' && vector_URL[i+1] != 'D' ||
           vector_URL[i+2]!= 'f' && vector_URL[i+2] != 'F')
        {
            throw logic_error("That is not a valid pdf url please try again. Make sure ending is pdf/PDF and beginning is http.");
        }

        //checks beginning of url for http link and throws exception if not
        int x = 0;// starts with the first letter in the url to see if it begins with h or not.
        if(vector_URL[x] != 'h'||
           vector_URL[x+1] != 't'||
           vector_URL[x+2] != 't'||
           vector_URL[x+3] != 'p')
        {
            throw logic_error("That is not a valid pdf url please try again. Make sure ending is pdf/PDF and beginning is http.");
        }
        string command = ("wget -O webfile.pdf ") + url;
        system(command.c_str());
        system( "gv webfile.pdf" );
    }
    catch(logic_error& e)
    {
        cerr << "error: " << e.what();
    }
    return 0;
}