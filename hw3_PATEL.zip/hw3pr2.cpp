// Mitesh Patel
// CSCE 121 - 507
// Due: February 24, 2015
// hw3pr2.cpp

// This program asks the user for input, and from that input utilizes a vector in a fibonacci fashion so when the last number in the vector divided by the next to last number will always be around 1.6.

#include "std_lib_facilities_4a.h"
// function prototype
void fibonacci(int x, int y, vector<int>& v, int n);

int main()
{
    try // start of try block
    {
        // three variables: x to hold first number user wants and y to hold second number user wants.
        // n is the size the user wants the vector to be
        int x, y;
        int n;
        cout << "Please provide the first and second number you would like to start the vector with seperated by a space.\n";
        cin >> x >> y;
        cout << "Please provide the number of fibonacci numbers you would like to generate: \n";
        cin >> n;
        if(n < 10) // condition in order to throw exception
            throw runtime_error("Size must be greater than 10");
        vector<int> v(n);
        fibonacci(x,y,v,n); // function call
    }
    catch (runtime_error& e) // catch block
    {
        cerr <<"error: "<< e.what() << '\n'; // cout error message
    }
    return 0;
}

// have to create reference to vector so the size is still the same size the user wants
void fibonacci(int x, int y, vector<int>& v, int n)
{
    v[0] = x;
    v[1] = y;
    for(int i = 2; i<= n-1; ++i) // for loop designated to create vector in fibonacci fashion
    {
        v[i] = v[i-2] + v[i-1];
    }
    
    cout <<"The last entry in the vector divided by the next-to-last entry is : ";
        cout << "\n" << static_cast<double>(v[n-1])/static_cast<double>(v[n-2]) << endl; // static_cast to convert int to double for precise output

}