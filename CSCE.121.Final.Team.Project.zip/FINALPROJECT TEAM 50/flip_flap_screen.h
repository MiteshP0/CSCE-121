#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand


//------------------------FlipFlap_Screen Class and Definitions-------------2 pancakes----------

class FlipFlap_Screen2P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button win_button;
    Out_box num_flips;
    Out_box total_score;
    Image stop;
    Text minimum;
    void quit(); //quit button in case user wants to rage quit
    Button flip_button;
    void flip();
    void win();
public:
    FlipFlap_Screen2P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen2P::FlipFlap_Screen2P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen2P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen2P>(pw).flip();}},
num_flips{Point{100,20},50,30, "flip count"},
total_score{Point{300,20},50,30, "Score"},
minimum{Point{100,70},"1 flip Minimum"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen2P>(pw).win();}}, // creates next_button// creates flip_button
stop{Point{400,35}, "stop.png"}
{
    num_cakes = 2;
    srand (unsigned(std::time(0)));
    //------------normal vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
    }
    
    widths[0] = 30;
    widths[1] = 60;
    
    // -----nromal vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    
    int starting_c = 0;
    vector<int> column;
    for(int i = 1; i<= num_cakes; ++i)
    {
        column.push_back(starting_c);
        starting_c -= 15;
    }
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    random_shuffle(pancakes.begin(), pancakes.end(), myrandom);  //This is where the random vector is created
    attach(num_flips);
    attach(flip_button);
    attach(total_score);
    minimum.set_color(Color::black);
    attach(minimum);
    
    attach(quit_button);
    Fl::redraw();
}

void FlipFlap_Screen2P::win() //Where the next button takes you when you win
{
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}

void FlipFlap_Screen2P::quit()
{
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}
void FlipFlap_Screen2P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips); //Out box can't take an int so must convert to string first
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    
    if(widths[0]==30&&widths[1]==60)	//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    for(int i = 0; i < num_cakes; ++i){   //Detaches current pancakes
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end());  //reverses widths
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)  //Don't know how to change this. When I did it threw an error
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------












//------------------------FlipFlap_Screen Class and Definitions-------------3 pancakes----------

class FlipFlap_Screen3P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button flip_button2; //Flips mid and top
    Out_box num_flips;
    Out_box total_score;
    Button win_button;
    Text minimum;
    Image stop;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    Button flip_button;
    void flip(); //flips all
    void flip2(); // flips mid and top
    void win();
    
public:
    FlipFlap_Screen3P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen3P::FlipFlap_Screen3P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen3P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen3P>(pw).flip();}},
flip_button2{Point{120,475},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen3P>(pw).flip2();}},
num_flips{Point{100,20},50,30, "flip count"},
total_score{Point{300,20},50,30, "Score"},
minimum{Point{100,70},"2 flip Minimum"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen3P>(pw).win();}}, // creates next_button
stop{Point{400,35}, "stop.png"}

{
    num_cakes = 3;
    srand (unsigned(std::time(0)));
    //------------normal vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
        
    }
    
    random_shuffle(widths.begin(),widths.end(),myrandom);
    if(widths[0] == 90&& widths[1] == 60&&widths[2] ==30){
        while(widths[0] == 90&& widths[1] == 60&&widths[2] ==30){
            random_shuffle(widths.begin(),widths.end(),myrandom);
        }
        
    }//make sure it's not the answer
    
    
    // -----random vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    
    
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    //random_shuffle(pancakes.begin(), pancakes.end(), myrandom);
    
    attach(flip_button);
    attach(flip_button2);
    attach(total_score);
    attach(num_flips);
    minimum.set_color(Color::black);
    attach(minimum);
    attach(quit_button);
    Fl::redraw();
}
void FlipFlap_Screen3P::win(){
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}

void FlipFlap_Screen3P::quit()
{
    
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}
void FlipFlap_Screen3P::flip2()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips); //convert int to string
    num_flips.put(number); //out box output
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==90&&widths[1]==30&&widths[2]==60)    //The top button needs this order for it to be right
    {
        
        attach(win_button);
        attach(stop);
    }
    
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+1,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    Fl::redraw();
}
void FlipFlap_Screen3P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips); //int to string conversion
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==30&&widths[1]==60&&widths[2]==90)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end()); //swaps all
    
    //All below is just redrawing the pancakes with their new widths based on the reverse function
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    
    
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------













//------------------------FlipFlap_Screen Class and Definitions-------------4 pancakes----------

class FlipFlap_Screen4P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button flip_button2;
    Button flip_button3;
    Out_box num_flips;
    Out_box total_score;
    Button win_button;
    Text minimum;
    Image stop;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    Button flip_button;
    void flip();
    void flip2();
    void flip3();
    void win();
public:
    FlipFlap_Screen4P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen4P::FlipFlap_Screen4P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen4P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen4P>(pw).flip();}},
flip_button2{Point{120,475},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen4P>(pw).flip2();}},
flip_button3{Point{120,450},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen4P>(pw).flip3();}},
num_flips{Point{100,20},50,30, "flip count"},
total_score{Point{300,20},50,30, "Score"},
minimum{Point{100,70},"3 flip Minimum"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen4P>(pw).win();}}, // creates next_button
stop{Point{400,35}, "stop.png"}

{
    num_cakes = 4;
    srand (unsigned(std::time(0)));
    //------------random vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
    }
    random_shuffle(widths.begin(),widths.end(),myrandom);
    if(widths[0] == 120&& widths[1] == 90&&widths[2] ==60&& widths[3]==30){
        while(widths[0] == 120&& widths[1] == 90&&widths[2] ==60&&widths[3]==30){
            random_shuffle(widths.begin(),widths.end(),myrandom);
        }
    }//make sure it's not the answer
    
    
    // -----random vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    
    //--------random vector of rectangles with the random row and width above
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    attach(flip_button);
    attach(flip_button2);
    attach(flip_button3);
    attach(num_flips);
    attach(total_score);
    minimum.set_color(Color::black);
    attach(minimum);
    attach(quit_button);
    Fl::redraw();
}

void FlipFlap_Screen4P::win(){
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}

void FlipFlap_Screen4P::quit()
{
    
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}
void FlipFlap_Screen4P::flip3()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==120&&widths[1]==90&&widths[2]==30&&widths[3]==60)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+2,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen4P::flip2()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==120&&widths[1]==30&&widths[2]==60&&widths[3]==90)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+1,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen4P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==30&&widths[1]==60&&widths[2]==90&&widths[3]==120)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end());
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    
    
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------






//------------------------FlipFlap_Screen Class and Definitions-------------5 pancakes----------
class FlipFlap_Screen5P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button flip_button2;
    Button flip_button3;
    Button flip_button4;
    Out_box num_flips;
    Out_box total_score;
    Button win_button;
    Text minimum;
    Image stop;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    Button flip_button;
    void flip();
    void flip2();
    void flip3();
    void flip4();
    void win();
public:
    FlipFlap_Screen5P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen5P::FlipFlap_Screen5P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen5P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen5P>(pw).flip();}},
flip_button2{Point{120,475},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen5P>(pw).flip2();}},
flip_button3{Point{120,450},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen5P>(pw).flip3();}},
flip_button4{Point{120,425},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen5P>(pw).flip4();}},
minimum{Point{100,70},"4 flip Minimum"},
num_flips{Point{100,20},50,30, "flip count"},
total_score{Point{300,20},50,30, "Score"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen5P>(pw).win();}}, // creates next_button
stop{Point{400,35}, "stop.png"}

{
    num_cakes = 5;
    srand (unsigned(std::time(0)));
    //------------random vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
    }
    random_shuffle(widths.begin(),widths.end(),myrandom);
    if(widths[0] == 150&& widths[1] == 120&&widths[2] ==90&& widths[3]==60&&widths[4]==30){
        while(widths[0] == 150&& widths[1] == 120&&widths[2] ==90&&widths[3]==60&&widths[4]==30){
            random_shuffle(widths.begin(),widths.end(),myrandom);
        }
    }//make sure it's not the answer
    // -----random vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    attach(flip_button);
    attach(flip_button2);
    attach(flip_button3);
    attach(flip_button4);
    attach(num_flips);
    minimum.set_color(Color::black);
    attach(minimum);
    attach(total_score);
    attach(quit_button);
    Fl::redraw();
}

void FlipFlap_Screen5P::win(){
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}
void FlipFlap_Screen5P::quit()
{
    
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}
void FlipFlap_Screen5P::flip4()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==150&&widths[1]==120&&widths[2]==90&&widths[3]==30&&widths[4]==60)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip

    reverse(widths.begin()+3,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen5P::flip3()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==150&&widths[1]==120&&widths[2]==30&&widths[3]==60&&widths[4]==90)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+2,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen5P::flip2()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==150&&widths[1]==30&&widths[2]==60&&widths[3]==90&&widths[4]==120)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+1,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen5P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==30&&widths[1]==60&&widths[2]==90&&widths[3]==120&&widths[4]==150)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end());
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    
    
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------










//------------------------FlipFlap_Screen Class and Definitions-------------6 pancakes----------

class FlipFlap_Screen6P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button flip_button2;
    Button flip_button3;
    Button flip_button4;
    Button flip_button5;
    Out_box total_score;
    Out_box num_flips;
    Button win_button;
    Text minimum;
    Image stop;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    Button flip_button;
    void flip();
    void flip2();
    void flip3();
    void flip4();
    void flip5();
    void win();
public:
    FlipFlap_Screen6P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen6P::FlipFlap_Screen6P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen6P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen6P>(pw).flip();}},
flip_button2{Point{120,475},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen6P>(pw).flip2();}},
flip_button3{Point{120,450},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen6P>(pw).flip3();}},
flip_button4{Point{120,425},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen6P>(pw).flip4();}},
flip_button5{Point{120,400},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen6P>(pw).flip5();}},
num_flips{Point{100,20},50,30, "flip count"},
minimum{Point{100,70},"5 flip Minimum"},
total_score{Point{300,20},50,30, "Score"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen6P>(pw).win();}}, // creates next_button
stop{Point{400,35}, "stop.png"}

{
    num_cakes = 6;
    srand (unsigned(std::time(0)));
    //------------random vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
    }
    random_shuffle(widths.begin(),widths.end(),myrandom);
    if(widths[0] == 180&& widths[1] == 150&&widths[2] ==120&& widths[3]==90&&widths[4]==60&&widths[5]==30){
        while(widths[0] == 180&& widths[1] == 150&&widths[2] ==120&&widths[3]==90&&widths[4]==60&&widths[6]==30){
            random_shuffle(widths.begin(),widths.end(),myrandom);
        }
    }//make sure it's not the answer
    
    // -----random vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    attach(flip_button);
    attach(flip_button2);
    attach(flip_button3);
    attach(flip_button4);
    attach(flip_button5);
    attach(num_flips);
    attach(total_score);
    minimum.set_color(Color::black);
    attach(minimum);
    attach(quit_button);
    Fl::redraw();
}

void FlipFlap_Screen6P::win()
{
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}
void FlipFlap_Screen6P::quit()
{
    
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}
void FlipFlap_Screen6P::flip5()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==180&&widths[1]==150&&widths[2]==120&&widths[3]==90&&widths[4]==30&&widths[5]==60)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+4,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen6P::flip4()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==180&&widths[1]==150&&widths[2]==120&&widths[3]==30&&widths[4]==60&&widths[5]==90)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+3,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen6P::flip3()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==180&&widths[1]==150&&widths[2]==30&&widths[3]==60&&widths[4]==90&&widths[5]==120)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+2,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen6P::flip2()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==180&&widths[1]==30&&widths[2]==60&&widths[3]==90&&widths[4]==120&&widths[5]==150)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+1,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen6P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==30&&widths[1]==60&&widths[2]==90&&widths[3]==120&&widths[4]==150&&widths[5]==180)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end());
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    
    
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------








//------------------------FlipFlap_Screen Class and Definitions------------- 7 pancakes----------

class FlipFlap_Screen7P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button flip_button2;
    Button flip_button3;
    Button flip_button4;
    Button flip_button5;
    Button flip_button6;
    Out_box num_flips;
    Out_box total_score;
    Text minimum;
    Button win_button;
    Image stop;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    Button flip_button;
    void flip();
    void flip2();
    void flip3();
    void flip4();
    void flip5();
    void flip6();
    void win();
public:
    FlipFlap_Screen7P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen7P::FlipFlap_Screen7P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).flip();}},
flip_button2{Point{120,475},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).flip2();}},
flip_button3{Point{120,450},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).flip3();}},
flip_button4{Point{120,425},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).flip4();}},
flip_button5{Point{120,400},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).flip5();}},
flip_button6{Point{120,375},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).flip6();}},
minimum{Point{100,70},"6 flip Minimum"},
num_flips{Point{100,20},50,30, "flip count"},
total_score{Point{300,20},50,30, "Score"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen7P>(pw).win();}}, // creates next_button
stop{Point{400,35}, "stop.png"}

{
    num_cakes = 7;
    srand (unsigned(std::time(0)));
    //------------random vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
    }
    random_shuffle(widths.begin(),widths.end(),myrandom);
    if(widths[0] == 210&& widths[1] == 180&&widths[2] ==150&& widths[3]==120&&widths[4]==90&&widths[5]==60&&widths[6]==30){
        while(widths[0] == 210&& widths[1] == 180&&widths[2] ==150&& widths[3]==120&&widths[4]==90&&widths[5]==60&&widths[6]==30){
            random_shuffle(widths.begin(),widths.end(),myrandom);
        }
    }//make sure it's not the answer
    
    // -----random vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    attach(flip_button);
    attach(flip_button2);
    attach(flip_button3);
    attach(flip_button4);
    attach(flip_button5);
    minimum.set_color(Color::black);
    attach(minimum);
    attach(flip_button6);
    attach(num_flips);
    attach(total_score);
    attach(quit_button);
    Fl::redraw();
}

void FlipFlap_Screen7P::win(){
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}
void FlipFlap_Screen7P::quit()
{
    
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}
void FlipFlap_Screen7P::flip6()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==210&&widths[1]==180&&widths[2]==150&&widths[3]==120&&widths[4]==90&&widths[5]==30&&widths[6]==60)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+5,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen7P::flip5()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==210&&widths[1]==180&&widths[2]==150&&widths[3]==120&&widths[4]==30&&widths[5]==60&&widths[6]==90)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+4,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen7P::flip4()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==210&&widths[1]==180&&widths[2]==150&&widths[3]==30&&widths[4]==60&&widths[5]==90&&widths[6]==120)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    
    reverse(widths.begin()+3,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen7P::flip3()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==210&&widths[1]==180&&widths[2]==30&&widths[3]==60&&widths[4]==90&&widths[5]==120&&widths[6]==150)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+2,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen7P::flip2()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==210&&widths[1]==30&&widths[2]==60&&widths[3]==90&&widths[4]==120&&widths[5]==150&&widths[6]==180)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+1,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen7P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==30&&widths[1]==60&&widths[2]==90&&widths[3]==120&&widths[4]==150&&widths[5]==180&&widths[6]==210)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end());
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    
    
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------





//------------------------FlipFlap_Screen Class and Definitions------------- 8 pancakes----------

class FlipFlap_Screen8P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button flip_button2;
    Button flip_button3;
    Button flip_button4;
    Button flip_button5;
    Button flip_button6;
    Button flip_button7;
    Out_box num_flips;
    Out_box total_score;
    Text minimum;
    Button win_button;
    Image stop;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    Button flip_button;
    void flip();
    void flip2();
    void flip3();
    void flip4();
    void flip5();
    void flip6();
    void flip7();
    void win();
public:
    FlipFlap_Screen8P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen8P::FlipFlap_Screen8P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).flip();}},
flip_button2{Point{120,475},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).flip2();}},
flip_button3{Point{120,450},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).flip3();}},
flip_button4{Point{120,425},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).flip4();}},
flip_button5{Point{120,400},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).flip5();}},
flip_button6{Point{120,375},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).flip6();}},
flip_button7{Point{120,350},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).flip7();}},
minimum{Point{100,70},"7 flip Minimum"},
num_flips{Point{100,20},50,30, "flip count"},
total_score{Point{300,20},50,30, "Score"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen8P>(pw).win();}},// creates next_button
stop{Point{400,35}, "stop.png"}

{
    num_cakes = 8;
    srand (unsigned(std::time(0)));
    //------------random vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
    }
    random_shuffle(widths.begin(),widths.end(),myrandom);
    if(widths[0] == 240&& widths[1] == 210&&widths[2] ==180&& widths[3]==150&&widths[4]==120&&widths[5]==90&&widths[6]==60&&widths[7]==30){
        while(widths[0] == 240&& widths[1] == 210&&widths[2] ==180&& widths[3]==150&&widths[4]==120&&widths[5]==90&&widths[6]==60&&widths[7]==30){
            random_shuffle(widths.begin(),widths.end(),myrandom);
        }
    }//make sure it's not the answer
    // -----random vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    random_shuffle(pancakes.begin(), pancakes.end(), myrandom);
    attach(flip_button);
    attach(flip_button2);
    attach(flip_button3);
    attach(flip_button4);
    attach(flip_button5);
    attach(flip_button6);
    attach(flip_button7);
    minimum.set_color(Color::black);
    attach(minimum);
    attach(num_flips);
    attach(total_score);
    attach(quit_button);
    Fl::redraw();
}
void FlipFlap_Screen8P::win(){
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}

void FlipFlap_Screen8P::quit()
{
    
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}
void FlipFlap_Screen8P::flip7()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==240&&widths[1]==210&&widths[2]==180&&widths[3]==150&&widths[4]==120&&widths[5]==90&&widths[6]==30&&widths[7]==60)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+6,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}


void FlipFlap_Screen8P::flip6()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==240&&widths[1]==210&&widths[2]==180&&widths[3]==150&&widths[4]==120&&widths[5]==30&&widths[6]==60&&widths[7]==90)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+5,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen8P::flip5()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==240&&widths[1]==210&&widths[2]==180&&widths[3]==150&&widths[4]==30&&widths[5]==60&&widths[6]==90&&widths[7]==120)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+4,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen8P::flip4()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==240&&widths[1]==210&&widths[2]==180&&widths[3]==30&&widths[4]==60&&widths[5]==90&&widths[6]==120&&widths[7]==150)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    
    reverse(widths.begin()+3,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen8P::flip3()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==240&&widths[1]==210&&widths[2]==30&&widths[3]==60&&widths[4]==90&&widths[5]==120&&widths[6]==150&&widths[7]==180)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+2,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen8P::flip2()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==240&&widths[1]==30&&widths[2]==60&&widths[3]==90&&widths[4]==120&&widths[5]==150&&widths[6]==180&&widths[7]==210)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+1,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen8P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==30&&widths[1]==60&&widths[2]==90&&widths[3]==120&&widths[4]==150&&widths[5]==180&&widths[6]==210&&widths[7]==240)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end());
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    
    
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------




//------------------------FlipFlap_Screen Class and Definitions------------- 9 pancakes----------

class FlipFlap_Screen9P : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    Button flip_button2;
    Button flip_button3;
    Button flip_button4;
    Button flip_button5;
    Button flip_button6;
    Button flip_button7;
    Button flip_button8;
    Text minimum;
    Button win_button;
    Image stop;
    Out_box num_flips;
    Out_box total_score;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    Button flip_button;
    void flip();
    void flip2();
    void flip3();
    void flip4();
    void flip5();
    void flip6();
    void flip7();
    void flip8();
    void win();
public:
    FlipFlap_Screen9P(Point xy, int w, int h, const string& title);
};
//constructor
FlipFlap_Screen9P::FlipFlap_Screen9P(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"Quit?",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).quit();}},// creates quit_button
flip_button{Point{120,500},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip();}},
flip_button2{Point{120,475},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip2();}},
flip_button3{Point{120,450},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip3();}},
flip_button4{Point{120,425},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip4();}},
flip_button5{Point{120,400},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip5();}},
flip_button6{Point{120,375},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip6();}},
flip_button7{Point{120,350},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip7();}},
flip_button8{Point{120,325},40,20,"Flip",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).flip8();}},
minimum{Point{100,70},"8 flip Minimum"},
num_flips{Point{100,20},50,30, "flip count"},
total_score{Point{300,20},50,30, "Score"},
win_button{Point{635,300},150,50,"Nice Job! NEXT",[](Address, Address pw){reference_to<FlipFlap_Screen9P>(pw).win();}}, // creates next_button
stop{Point{400,35}, "stop.png"}

{
    num_cakes = 9;
    srand (unsigned(std::time(0)));
    //------------random vector of widths
    
    for(int i = 0; i < num_cakes; ++i)
    {
        int width = (i+1)*30;
        widths.push_back(width);
    }
    random_shuffle(widths.begin(),widths.end(),myrandom);
    if(widths[0] == 270&& widths[1] == 240&&widths[2] ==210&& widths[3]==180&&widths[4]==150&&widths[5]==90&&widths[6]==60&&widths[7]==30){
        while(widths[0] == 240&& widths[1] == 210&&widths[2] ==180&& widths[3]==150&&widths[4]==120&&widths[5]==90&&widths[6]==60&&widths[7]==30){
            random_shuffle(widths.begin(),widths.end(),myrandom);
        }
    }//make sure it's not the answer
    
    // -----random vector of points (row)
    int starting_row = 500;
    vector<int> row;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    
    
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center.push_back(factor);
    }
    //--------random vector of rectangles with the random row and width above
    
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes.push_back(new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    random_shuffle(pancakes.begin(), pancakes.end(), myrandom);
    attach(flip_button);
    attach(flip_button2);
    attach(flip_button3);
    attach(flip_button4);
    attach(flip_button5);
    attach(flip_button6);
    attach(flip_button7);
    attach(flip_button8);
    minimum.set_color(Color::black);
    attach(minimum);
    attach(num_flips);
    attach(total_score);
    attach(quit_button);
    Fl::redraw();
}
void FlipFlap_Screen9P::win(){
    
    hide();
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.show();
    while(total.shown()) Fl::wait();
}
void FlipFlap_Screen9P::quit()
{
    
    hide();
    string_score = "N/A";
    Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
    total.hide();
    Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
    fail.show();
    while(fail.shown()) Fl::wait();
}

void FlipFlap_Screen9P::flip8()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==270&&widths[1]==240&&widths[2]==210&&widths[3]==180&&widths[4]==150&&widths[5]==120&&widths[6]==90&&widths[7]==30&&widths[8]==60)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+7,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen9P::flip7()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==270&&widths[1]==240&&widths[2]==210&&widths[3]==180&&widths[4]==150&&widths[5]==120&&widths[6]==30&&widths[7]==60&&widths[8]==90)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+6,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}


void FlipFlap_Screen9P::flip6()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==270&&widths[1]==240&&widths[2]==210&&widths[3]==180&&widths[4]==150&&widths[5]==30&&widths[6]==60&&widths[7]==90&&widths[8]==120)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+5,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen9P::flip5()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==270&&widths[1]==240&&widths[2]==210&&widths[3]==180&&widths[4]==30&&widths[5]==60&&widths[6]==90&&widths[7]==120&&widths[8]==150)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+4,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}

void FlipFlap_Screen9P::flip4()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==270&&widths[1]==240&&widths[2]==210&&widths[3]==30&&widths[4]==60&&widths[5]==90&&widths[6]==120&&widths[7]==150&&widths[8]==180)		//Checks to see if the pancakes are ordered correctly
    {
        
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+3,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen9P::flip3()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==270&&widths[1]==240&&widths[2]==30&&widths[3]==60&&widths[4]==90&&widths[5]==120&&widths[6]==150&&widths[7]==180&&widths[8]==210)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    
    reverse(widths.begin()+2,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen9P::flip2()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==270&&widths[1]==30&&widths[2]==60&&widths[3]==90&&widths[4]==120&&widths[5]==150&&widths[6]==180&&widths[7]==210&&widths[8]==240)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin()+1,widths.end());//somehow swaps top and mid
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    Fl::redraw();
}
void FlipFlap_Screen9P::flip()
{
    ++count_flips; // increment count flips
    
    string number = to_string(count_flips);
    num_flips.put(number); //For Out box. Must do this in each flip.
    
    score = get_score(count_flips,num_cakes);
    string_score = to_string(score);
    total_score.put(string_score);
    
    if(widths[0]==30&&widths[1]==60&&widths[2]==90&&widths[3]==120&&widths[4]==150&&widths[5]==180&&widths[6]==210&&widths[7]==240&&widths[8]==270)		//Checks to see if the pancakes are ordered correctly
    {
        attach(win_button);
        attach(stop);
    }
    
    if (score<0)
    {
        hide();
        string_score = "N/A";
        Total_Screen total{Point{250,100},800,600,"Total"}; //creates hidden total window
        total.hide();
        Failure_Screen fail{Point{250,100},800,600,"Failure"}; //creates hidden fail window
        fail.show();
        while(fail.shown()) Fl::wait();
        
    }
    for(int i = 0; i < num_cakes; ++i){
        detach(*pancakes[i]);
    }
    
    //for each button, set a value = where you want the screen to flip
    
    reverse(widths.begin(), widths.end());
    
    
    int starting_row = 500;
    for(int i = 1; i<= num_cakes; ++i)
    {
        row.push_back(starting_row);
        starting_row -= 25;
    }
    for(int i = 0; i < num_cakes; i++)
    {
        int factor = widths[i]/2;
        
        center[i]=factor;
    }
    for (int i = 0; i<num_cakes; ++i)
    {
        pancakes[i] = (new Rectangle{Point{300-center[i],row[i]}, widths[i], 20});
        pancakes[i]->set_color(Color::black);
        pancakes[i]->set_fill_color(Color::yellow);
        attach(*(pancakes[i]));
    }
    
    
    
    
    Fl::redraw();
    
}
//---------------------------------------------------------------------------------------
