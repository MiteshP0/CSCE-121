#ifndef TESTING_find_solution_h
#define TESTING_find_solution_h


//find solution that was provided by walter but doesnt work.
vector<int> *find_solution(vector<int>& pancakes);

#endif
