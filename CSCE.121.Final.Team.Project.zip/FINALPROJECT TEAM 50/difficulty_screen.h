#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand



//------------------------Difficulty_Screen Class and Definitions-------------------// difficulty screen will not have next button instead
// buttons number 2-9 that will go to that screen of pancakes
// the button will set a value and if that value is 2 it wall draw 2 pancakes if 3 will draw 3 pancakes and so on.
class Difficulty_Screen : public Graph_lib::Window //inherit from window
{
private:
    //difficulty buttons 2-9
    Button difficulty_two;
    Button difficulty_three;
    Button difficulty_four;
    Button difficulty_five;
    Button difficulty_six;
    Button difficulty_seven;
    Button difficulty_eight;
    Button difficulty_nine;
    Text welcome;
    Text initial;
    Text choose_difficulty;
    //Text to explain what each difficulty is
    Text difficulty_explain_two;
    Text difficulty_explain_three;
    Text difficulty_explain_four;
    Text difficulty_explain_five;
    Text difficulty_explain_six;
    Text difficulty_explain_seven;
    Text difficulty_explain_eight;
    Text difficulty_explain_nine;
    Lines seperator;
    void display2pancakes();
    void display3pancakes();
    void display4pancakes();
    void display5pancakes();
    void display6pancakes();
    void display7pancakes();
    void display8pancakes();
    void display9pancakes();
    void get_difficulty_explained(); //text to explain difficulties
    void attach_difficulties(); //attach all the buttons for difficulty
    void difficulty_screen_header(); //header for the screen
    void difficulty_header_seperator(); //seperate screen header from contents
    
public:
    Difficulty_Screen(Point xy, int w, int h, const string& title);
};

//constructor
Difficulty_Screen::Difficulty_Screen(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
difficulty_two{Point{245,235},50,50,"2",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display2pancakes();}},
difficulty_three{Point{320,235},50,50,"3",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display3pancakes();}},
difficulty_four{Point{395,235},50,50,"4",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display4pancakes();}},
difficulty_five{Point{470,235},50,50,"5",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display5pancakes();}},
difficulty_six{Point{245,310},50,50,"6",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display6pancakes();}},
difficulty_seven{Point{320,310},50,50,"7",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display7pancakes();}},
difficulty_eight{Point{395,310},50,50,"8",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display8pancakes();}},
difficulty_nine{Point{470,310},50,50,"9",[](Address, Address pw){reference_to<Difficulty_Screen>(pw).display9pancakes();}},
choose_difficulty{Point{120,125},"Choose your difficulty: "},
difficulty_explain_two{Point{45,245},"2 --- 2 pancakes"},
difficulty_explain_three{Point{45,290},"3 --- 3 pancakes"},
difficulty_explain_four{Point{45,335},"4 --- 4 pancakes"},
difficulty_explain_five{Point{45,380},"5 --- 5 pancakes"},
difficulty_explain_six{Point{580,245},"6 --- 6 pancakes"},
difficulty_explain_seven{Point{580,290},"7 --- 7 pancakes"},
difficulty_explain_eight{Point{580,335},"8 --- 8 pancakes"},
difficulty_explain_nine{Point{580,380},"9 --- 9 pancakes"},
welcome{Point{150,60},"Welcome, "},
initial{Point{420,60},player_initials}
{
    difficulty_screen_header();
    get_difficulty_explained();
    attach_difficulties();
    difficulty_header_seperator();
    Fl::redraw();
}

void Difficulty_Screen::display2pancakes()
{
    count_difficulty = 2;
    hide();
    FlipFlap_Screen2P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 2
    flip.show();
    while(flip.shown()) Fl::wait();
    
}

void Difficulty_Screen::display3pancakes()
{
    count_difficulty = 3;
    hide();
    FlipFlap_Screen3P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 3
    flip.show();
    while(flip.shown()) Fl::wait();
    
    
}

void Difficulty_Screen::display4pancakes()
{
    count_difficulty = 4;
    hide();
    FlipFlap_Screen4P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 3
    flip.show();
    while(flip.shown()) Fl::wait();
}

void Difficulty_Screen::display5pancakes()
{
    count_difficulty = 5;
    hide();
    FlipFlap_Screen5P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 3
    flip.show();
    while(flip.shown()) Fl::wait();
}

void Difficulty_Screen::display6pancakes()
{
    count_difficulty = 6;
    hide();
    FlipFlap_Screen6P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 3
    flip.show();
    while(flip.shown()) Fl::wait();
}


void Difficulty_Screen::display7pancakes()
{
    count_difficulty = 7;
    hide();
    FlipFlap_Screen7P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 3
    flip.show();
    while(flip.shown()) Fl::wait();
}


void Difficulty_Screen::display8pancakes()
{
    count_difficulty = 8;
    hide();
    FlipFlap_Screen8P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 3
    flip.show();
    while(flip.shown()) Fl::wait();
    
}
void Difficulty_Screen::display9pancakes()
{
    count_difficulty = 9;
    hide();
    FlipFlap_Screen9P flip{Point{250,100},800,600,"FlipFlap"}; //creates hidden FlipFlap window for button 3
    flip.show();
    while(flip.shown()) Fl::wait();
}
void Difficulty_Screen::get_difficulty_explained()
{
    //text to explain difficulties
    difficulty_explain_two.set_font_size(20);
    difficulty_explain_two.set_color(Color::black);
    difficulty_explain_three.set_font_size(20);
    difficulty_explain_three.set_color(Color::black);
    difficulty_explain_four.set_font_size(20);
    difficulty_explain_four.set_color(Color::black);
    difficulty_explain_five.set_font_size(20);
    difficulty_explain_five.set_color(Color::black);
    difficulty_explain_six.set_font_size(20);
    difficulty_explain_six.set_color(Color::black);
    difficulty_explain_seven.set_font_size(20);
    difficulty_explain_seven.set_color(Color::black);
    difficulty_explain_eight.set_font_size(20);
    difficulty_explain_eight.set_color(Color::black);
    difficulty_explain_nine.set_font_size(20);
    difficulty_explain_nine.set_color(Color::black);
    //attach the text
    attach(difficulty_explain_nine);
    attach(difficulty_explain_eight);
    attach(difficulty_explain_seven);
    attach(difficulty_explain_six);
    attach(difficulty_explain_five);
    attach(difficulty_explain_four);
    attach(difficulty_explain_three);
    attach(difficulty_explain_two);
}
void Difficulty_Screen::attach_difficulties()
{
    //attach all buttons
    attach(difficulty_nine);
    attach(difficulty_eight);
    attach(difficulty_seven);
    attach(difficulty_six);
    attach(difficulty_five);
    attach(difficulty_four);
    attach(difficulty_three);
    attach(difficulty_two);
}
void Difficulty_Screen::difficulty_screen_header()
{
    //text for the header
    initial.set_font_size(55);
    initial.set_color(Color:: red);
    welcome.set_font_size(55);
    welcome.set_color(Color:: black);
    choose_difficulty.set_font_size(55);
    choose_difficulty.set_color(Color:: black);
    //attach the text
    attach(choose_difficulty);
    attach(welcome);
    attach(initial);
}
void Difficulty_Screen::difficulty_header_seperator()
{
    //underline seperator
    seperator.add(Point{0,150}, Point{800,150});
    seperator.add(Point{0,500}, Point{800,500});
    seperator.set_style(Line_style{Line_style::solid,3});
    seperator.set_color(Color::black);
    //attach the object
    attach(seperator);
}
//---------------------------------------------------------------------------------------

