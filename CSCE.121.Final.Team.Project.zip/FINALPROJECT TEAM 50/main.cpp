//fltk headeres
#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
//built in c++ headers
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand
//headers from classes created
#include "total_screen.h"
#include "failure_screen.h"
#include "flip_flap_screen.h"
#include "difficulty_screen.h"
#include "Input_screen.h"
#include "Instructions_screen.h"
#include "start_screen.h"
//------------------------------------------------------------------------------------
using namespace Graph_lib;
using namespace std;
//-----------------------main----------------------------------------------------------
int main()
{
    try
    {
        Start_Screen splash{Point{250,100}, 800,600,"Start"}; // create start window
        return gui_main();
    }
    catch(exception& e)
    {
        cerr << "exception: " << e.what() << '\n';
        return 1;
    }
    catch (...)
    {
        cerr << "Some exception\n";
        return 2;
    }
    
    
}

