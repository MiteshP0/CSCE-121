#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand



//global variables
string player_initials; // used in input to set initials.
// used to get individual lines of file, DO NOT EDIT THESE VARIABLES, ONLY EDIT INSIDE THE FILE TO UPDATE SCORES
string first_initial;
string second_initial;
string third_initial;
string fourth_initial;
string fifth_initial;
string first_score;
string second_score;
string third_score;
string fourth_score;
string fifth_score;
// used to get individual lines of file, DO NOT EDIT THESE VARIABLES, ONLY EDIT INSIDE THE FILE TO UPDATE SCORES
string header_line;
string first_line;
string second_line;
string third_line;
string fourth_line;
string fifth_line;
//global int to hold which difficulty to calculate score
int count_difficulty;
int count_flips;
//int to hold pancakes that should be broadcasted onto the screen
int num_cakes;
// global vector for width row and pancakes
vector<int> widths;
vector<int> row;
vector<Rectangle*> pancakes;
vector<int> center;
int score;
string string_score;



//score function
int get_score(int flips, int difficulty)
{
    int score = (100-10*(flips-(difficulty-1)))*difficulty;
    return score;
}
// random generator function:
int myrandom (int i) { return std::rand()%i;}




//------------------------Total_Screen Class and Definitions(LAST SCREEN. should have quit button)-----------------------

class Total_Screen : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    void quit(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    void play();
    Image total;
    Text initial;
    Text score;
    void display_IS(); //display initial and score
    
public:
    Total_Screen(Point xy, int w, int h, const string& title);
};
//constructor
Total_Screen::Total_Screen(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"QUIT",[](Address, Address pw){reference_to<Total_Screen>(pw).quit();}},// creates quit_button
total{Point{0,0}, "total.png"},
initial{Point{115,350}, player_initials}, // gets player initials to display on screen.
score(Point{540,350}, string_score) // gets player score to display on screen

{
    display_IS();
    
    ofstream myfile2;
    myfile2.open ("scores.txt", ios::out | ios::app | ios::binary);
    myfile2 << string_score << '\n';
    myfile2.close();
    
    ifstream is("scores.txt");
    istream_iterator<string> start(is), end;
    vector<string> num(start, end);
    sort(num.begin(),num.end());
    
    ofstream file_out("scores.txt");
    copy(num.begin(), num.end(), ostream_iterator<string>(file_out,"\n"));
    
    attach(quit_button);
    Fl::redraw();
}
void Total_Screen::quit()
{
    
    hide();
}
void Total_Screen::play()
{
    hide();
    
    
}
void Total_Screen::display_IS()
{
    initial.set_color(Color::black);
    initial.set_font_size(65);
    score.set_color(Color::black);
    score.set_font_size(65);
    
    
    attach(score);
    attach(initial);
    attach(total);
}

