#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand








//------------------Start_Screen Class and Functions-------------------------------------

class Start_Screen : public Graph_lib::Window//inherit from window
{
    
private:
    Button next_button;
    Image pancake;
    void next(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    void get_initials(); //get scores from file
    void get_scores();
    
public:
    Start_Screen(Point xy, int w, int h, const string& title);
    
};
//constructor
Start_Screen::Start_Screen(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
next_button{Point{635,535},150,50,"Next",[](Address, Address pw){reference_to<Start_Screen>(pw).next();}},// creates next_button
pancake{Point{0,0}, "pancake.png"} // picture from google images.
{
    get_initials();
    get_scores();
    attach(pancake);
    attach(next_button);
    Fl::redraw();
}
void Start_Screen::next()
{
    hide();
    Instruction_Screen instructions{Point{250,100},800,600,"Instructions"};
    instructions.show();
    while(instructions.shown()) Fl::wait();
}
void Start_Screen::get_initials()
{
    ifstream inputFile;
    inputFile.open("initials.txt");
    inputFile >> first_initial;
    inputFile >> second_initial;
    inputFile >> third_initial;
    inputFile >> fourth_initial;
    inputFile >> fifth_initial;
    inputFile.close();
    
}
void Start_Screen::get_scores()
{
    ifstream inputFile;
    inputFile.open("scores.txt");
    inputFile >> first_score;
    inputFile >> second_score;
    inputFile >> third_score;
    inputFile >> fourth_score;
    inputFile >> fifth_score;
    inputFile.close();
    
}
//------------------------------------------------------------------------------------