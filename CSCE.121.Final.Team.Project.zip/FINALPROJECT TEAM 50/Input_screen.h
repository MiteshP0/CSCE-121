#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand






//------------------------------Input_Screen Class and Definitions---------------------

class Input_Screen : public Graph_lib::Window //inherit from window
{
private:
    Button next_button;
    In_box enter_initials;
    Text top_five;
    //text to display contents of file onto the screen. File has 6 lines each line is a string variable
    Text file_firstInitial;
    Text file_secondInitial;
    Text file_thirdInitial;
    Text file_fourthInitial;
    Text file_fifthInitial;
    
    Text file_firstScore;
    Text file_secondScore;
    Text file_thirdScore;
    Text file_fourthScore;
    Text file_fifthScore;
    
    Lines seperator;
    Image scoreHeader;
    Image numbering;
    void next(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    void display_scores(); //display contents of file
    void input_screen_header();
    void input_header_seperator();
    
public:
    Input_Screen(Point xy, int w, int h, const string& title);
};

//constructor
Input_Screen::Input_Screen(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
next_button{Point{635,535},150,50,"Next",[](Address, Address pw){reference_to<Input_Screen>(pw).next();}},// creates next_button
top_five{Point{250,100},"Top Five: "},
enter_initials{Point{550,450}, 75, 25, "Enter your intitals, then press next to select your difficulty: "},
scoreHeader{Point{75,165}, "scoreHead.png"},
numbering{Point{30,205}, "numbers.png"},
file_firstInitial{Point{120,250},first_initial},
file_secondInitial{Point{120,290},second_initial},
file_thirdInitial{Point{120,330},third_initial},
file_fourthInitial{Point{120,370},fourth_initial},
file_fifthInitial{Point{120,410},fifth_initial},
file_firstScore{Point{620,250},first_score},
file_secondScore{Point{620,290},second_score},
file_thirdScore{Point{620,330},third_score},
file_fourthScore{Point{620,370},fourth_score},
file_fifthScore{Point{620,410},fifth_score}
{
    input_screen_header();
    input_header_seperator();
    display_scores();
    attach(numbering);
    attach(enter_initials); // attach in box
    attach(next_button);
    attach(scoreHeader);
    Fl::redraw();
}
void Input_Screen::next()
{
    hide();
    player_initials = enter_initials.get_string();
    if(player_initials.empty())
        player_initials = "anon";
    
    ofstream myfile;
    myfile.open ("initials.txt", ios::out | ios::app | ios::binary);	//continually adds to the .bin file of initials
    myfile << player_initials << '\n';
    myfile.close();
    
    Difficulty_Screen difficulty{Point{250,100},800,600,"Difficulty"}; //creates hidden Difficulty window
    difficulty.show();
    while(difficulty.shown()) Fl::wait();
}
void Input_Screen::input_screen_header()
{
    //Display top five header line
    top_five.set_font_size(70);
    top_five.set_color(Color::black);
    //attach
    attach(top_five);
    
}
void Input_Screen::input_header_seperator()
{
    //underline seperator
    seperator.add(Point{0,150}, Point{800,150});
    seperator.add(Point{0,500}, Point{800,500});
    seperator.set_style(Line_style{Line_style::solid,3});
    seperator.set_color(Color::black);
    //attach
    attach(seperator);
}
void Input_Screen::display_scores()
{
    //display whats in the file
    file_firstInitial.set_font_size(30);
    file_firstInitial.set_color(Color::blue);
    file_secondInitial.set_font_size(30);
    file_secondInitial.set_color(Color::blue);
    file_thirdInitial.set_font_size(30);
    file_thirdInitial.set_color(Color::blue);
    file_fourthInitial.set_font_size(30);
    file_fourthInitial.set_color(Color::blue);
    file_fifthInitial.set_font_size(30);
    file_fifthInitial.set_color(Color::blue);
    
    file_firstScore.set_font_size(30);
    file_firstScore.set_color(Color::blue);
    file_secondScore.set_font_size(30);
    file_secondScore.set_color(Color::blue);
    file_thirdScore.set_font_size(30);
    file_thirdScore.set_color(Color::blue);
    file_fourthScore.set_font_size(30);
    file_fourthScore.set_color(Color::blue);
    file_fifthScore.set_font_size(30);
    file_fifthScore.set_color(Color::blue);
    
    
    attach(file_fifthInitial);
    attach(file_fourthInitial);
    attach(file_thirdInitial);
    attach(file_secondInitial);
    attach(file_firstInitial);
    attach(file_fifthScore);
    attach(file_fourthScore);
    attach(file_thirdScore);
    attach(file_secondScore);
    attach(file_firstScore);
    
}

//---------------------------------------------------------------------------------------