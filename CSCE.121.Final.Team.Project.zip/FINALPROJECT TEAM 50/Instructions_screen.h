#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand





//---------------------Instruction_Screen Class and Definitions-----------------------

class Instruction_Screen : public Graph_lib::Window //inherit from window
{
private:
    Text instructions;
    Text step_one;
    Text step_two;
    Text step_three;
    Text step_four;
    Text step_five;
    Lines seperator;
    Button next_button;
    void next(); // private call back function that should only set button pushed to true and hide the screen to mimic quitting.
    void get_steps(); // get the steps (all the text created)
    void instruction_screen_header(); // display header
    void instruction_header_seperator(); // seperate header from contents of screen
public:
    Instruction_Screen(Point xy, int w, int h, const string& title);
};

//constructor
Instruction_Screen::Instruction_Screen(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
next_button{Point{635,535},150,50,"Next",[](Address, Address pw){reference_to<Instruction_Screen>(pw).next();}},// creates next_button
instructions{Point{230,100},"Instructions"},
step_one{Point{25,200},"- Choose difficulty (2 to 9)."},
step_two{Point{25,260},"- Enter initials on next screen."},
step_three{Point{25,320},"- Press flip next to pancake you wish to flip over."},
step_four{Point{25,380},"- If score becomes less than 0, it will end!"},
step_five{Point{25,440},"- If your score is in top 5, your score will be saved."}

{
    instruction_screen_header();
    instruction_header_seperator();
    get_steps();
    attach(next_button);
    Fl::redraw();
}
void Instruction_Screen::next()
{
    hide();
    Input_Screen input{Point{250,100},800,600,"Input"}; //creates hidden Input window
    input.show();
    while(input.shown()) Fl::wait();
}
void Instruction_Screen::get_steps()
{
    //steps
    step_one.set_font_size(30);
    step_one.set_color(Color::black);
    step_two.set_font_size(30);
    step_two.set_color(Color::black);
    step_three.set_font_size(30);
    step_three.set_color(Color::black);
    step_four.set_font_size(30);
    step_four.set_color(Color::black);
    step_five.set_font_size(30);
    step_five.set_color(Color::black);
    
    attach(step_five);
    attach(step_four);
    attach(step_three);
    attach(step_two);
    attach(step_one);
}
void Instruction_Screen::instruction_screen_header()
{
    //Display instruction header line
    instructions.set_font_size(70);
    instructions.set_color(Color::black);
    //attach
    attach(instructions);
}
void Instruction_Screen::instruction_header_seperator()
{
    //underline seperator
    seperator.add(Point{0,150}, Point{800,150});
    seperator.add(Point{0,500}, Point{800,500});
    seperator.set_style(Line_style{Line_style::solid,3});
    seperator.set_color(Color::black);
    //attach
    attach(seperator);
}
//-------------------------------------------------------------------------------------