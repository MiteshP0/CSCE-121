#include "Graph.h"
#include "GUI.h"
#include "Simple_window.h"
#include "Point.h"
#include <algorithm>    // std::random_shuffle
#include <vector>       // std::vector
#include <ctime>        // std::time
#include <cstdlib>      // std::rand, std::srand

//------------------------Failure_Screen Class and Definitions-----------------------

class Failure_Screen : public Graph_lib::Window //inherit from window
{
private:
    Button quit_button;
    void quit(); // quit button
    Image failed;
public:
    Failure_Screen(Point xy, int w, int h, const string& title);
};

//constructor
Failure_Screen::Failure_Screen(Point xy,int w, int h, const string& title)
:Window{xy,w,h,title},
quit_button{Point{635,535},150,50,"QUIT",[](Address, Address pw){reference_to<Failure_Screen>(pw).quit();}}, // creates next_button
failed{Point{0,0}, "failed.png"} // image from google images

{
    attach(quit_button);
    attach(failed);
    Fl::redraw();
}
void Failure_Screen::quit()
{
    
    hide();
}
//---------------------------------------------------------------------------------------

