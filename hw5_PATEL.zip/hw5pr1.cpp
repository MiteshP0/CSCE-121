//Mitesh Patel
//CSCE 121 - 507
//Due: March 26, 2015
//hw5pr1.cpp

#include "std_lib_facilities_4.h"
#include "Simple_window.h"
#include "Graph.h"


int main()
{
try
{
    if(H112 != 201401L)error("Error: incorrect std_lib_facilities_4.h version ",
            H112);
    // create window
    Simple_window win(Point(100,200),600,400,"hw5pr1");
    // create letters from using lines 150 pixil high.
    Lines m, p;
    //coordinates for M
    m.add(Point{50,300}, Point{50,150});
    m.add(Point{50,150}, Point{150,300});
    m.add(Point{150,300}, Point{250,150});
    m.add(Point{250,150}, Point{250,300});
    m.set_style(Line_style{Line_style::solid,7}); //Thick line
    m.set_color(Color::red); // set color
    //coordinates for P
    p.add(Point{400,300}, Point{400,150});
    p.add(Point{400,150}, Point{500,150});
    p.add(Point{500,150}, Point{500,225});
    p.add(Point{500,225}, Point{400,225});
    p.set_style(Line_style{Line_style::solid,7}); //Thick line
    p.set_color(Color::blue); // set color
    win.attach(m);
    win.attach(p);
    win.wait_for_button();
    return 0;
}
catch(exception& e) {
    cerr << "exception: " << e.what() << '\n';
	return 1;
}
catch (...)
{
	cerr << "Some exception\n";
	return 2;
}
}