//Mitesh Patel
//CSCE 121 - 507
//Due: March 26, 2015
//hw5pr2.cpp

#include "std_lib_facilities_4.h"
#include "Simple_window.h"
#include "Graph.h"
using namespace Graph_lib;


int main()
{
try
{
    if(H112 != 201401L)error("Error: incorrect std_lib_facilities_4.h version ",
            H112);
    // create window
    Simple_window win(Point(100,200),600,400,"hw5pr2");
	//create square
	Polygon square;
	square.add(Point(200,300));
	square.add(Point(200,100));
	square.add(Point(400,100));
	square.add(Point(400,300));
	square.set_color(fl_rgb_color(80,0,0)); // set outline dark red
	square.set_fill_color(fl_rgb_color(80,0,0)); // set fill color to dark red
	//create background white
    Rectangle background_color{Point(0,20),600,400};
    background_color.set_fill_color(Color::white);
    //create the A the T and the M
    
    Text a{Point{220,240},"A"};
    a.set_color(Color::white);
    a.set_font_size(100);

	Text t{Point{233,255},"T"};
    t.set_color(Color::white);
    t.set_font_size(220);
    t.set_font(Graph_lib::Font::courier);
    
    Text m{Point{310,240},"M"};
    m.set_color(Color::white);
    m.set_font_size(100);
    

    //attach objects
    win.attach(background_color);
	win.attach(square);
    win.attach(a);
    win.attach(t);
    win.attach(m);
	win.wait_for_button();
	
    return 0;
}
catch(exception& e) {
    cerr << "exception: " << e.what() << '\n';
	return 1;
}
catch (...)
{
	cerr << "Some exception\n";
	return 2;
}
}