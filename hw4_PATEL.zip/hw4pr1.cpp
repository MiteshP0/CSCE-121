//Mitesh Patel
//CSCE 121 - 507
//Due: March 5, 2015
//hw4pr2.cpp

//This program will calculate the roots and the residual from a quadratic equation in the form of ax^2+bx+c=0 where c is a constant. Also, this program will display a message if the root is complex.

#include "std_lib_facilities_4a.h"
//Function prototypes
double quadratic_equation_addition(const double a, const double b, const double c);
double quadratic_equation_subtraction(const double a, const double b, const double c);
double calculate_x1_residual(const double x1, const double a, const double b, const double c);
double calculate_x2_residual(const double x2, const double a, const double b, const double c);

int main()
{
    char again; // for condition to reloop
    do
    {
        try
        {
            double a, b, c;
            cout << "Enter any number for the variables a, b, and c (seperated by a space) so I can solve the quadratic equation in the form of (ax^2+bx+c=0) where c is a constant.\n"; //prompt
            cin >> a >> b >> c;
            double x1 = quadratic_equation_addition(a,b,c);
            double residual_x1 = calculate_x1_residual(x1,a,b,c);
            cout << "x1 = " << x1 << "\t \t" << "Residual is: " << residual_x1 << endl;
            double x2 = quadratic_equation_subtraction(a,b,c);
            double residual_x2 = calculate_x2_residual(x2,a,b,c);
            cout << "x2 = " << x2 << "\t \t" << "Residual is: " << residual_x2 << endl;
            
        }
        catch(logic_error&e) //catch logic error for complex root
        {
            cerr << "error: "<< e.what() << endl;
            
        }
        cout << endl; // for spacing
        cout << "Do you want to try again with different values? (Y or N)\n";
        cin >> again;
        if(again == 'n' || again == 'N')
            exit(1); // exit if user enters n
    }while(again == 'y' || again =='Y');
    return 0;
}

//This function returns the result of the variables plugged into the quadratic equation when
//-b + sqrt(b^2-4ac)/2a
double quadratic_equation_addition(const double a, const double b, const double c)
{
    double to_be_squared = pow(b,2.0)-(4*a*c);
    if(to_be_squared<0)
        throw logic_error("Roots are complex");
    double quadratic_formula_added = (-b+(sqrt(to_be_squared)))/(2*a);
    return quadratic_formula_added;
}

//This function returns the result of the variables plugged into the quadratic equation when
//-b - sqrt(b^2-4ac)/2a
double quadratic_equation_subtraction(const double a, const double b, const double c)
{
    double to_be_squared = pow(b,2.0)-(4*a*c);
    if(to_be_squared<0)
        throw logic_error("Roots are complex");
    double quadratic_formula_subtracted = (-b-(sqrt(to_be_squared)))/(2*a);
    return quadratic_formula_subtracted;
}

//This function will return the residual of the value from the quadratic_equation_addition which should be 0 or very close to 0.
double calculate_x1_residual(const double x1, const double a, const double b, const double c)
{
    //equation is ax1^2 + bx1 + c
    double residual_x1 = a*(pow(x1,2.0)) + b*x1 + c;
    return residual_x1;
}

//This function will return the residual of the value from the quadratic_equation_subtraction which should be 0 or very close to 0.
double calculate_x2_residual(const double x2, const double a, const double b, const double c)
{
    //equation is ax2^2 + bx2 + c
    double residual_x2 = a*(pow(x2,2.0)) + b*x2 + c;
    return residual_x2;
}
