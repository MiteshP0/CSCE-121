//Mitesh Patel
//CSCE 121 - 507
//Due: March 5, 2015
//hw4pr3.cpp

#include "std_lib_facilities_4a.h"
bool yes(); // function prototype
enum quest
{
    question1=1, question2=2, question3=4
};

int main()
{
    // Pre-made answers to push back into vector
    string answer1 = "You must like playing a lot of video games.";
    string answer2 = "I bet you like to mess with computers.";
    string answer3 = "You must like playing games that are on computers.";
    string answer4 = "You must be majoring in biology or chemistry.";
    string answer5 = "You must like playing games regarding science.";
    string answer6 = "You must be majoring in computer science.";
    string answer7 = "I bet you love programming in c++ to make games regarding science.";
    // vector to hold the answers
    vector<string> answer;
    // push back answers into vector
    answer.push_back(answer1); //answer[0]
    answer.push_back(answer2); //answer[1]
    answer.push_back(answer3); //answer[2]
    answer.push_back(answer4); //answer[3]
    answer.push_back(answer5); //answer[4]
    answer.push_back(answer6); //answer[5]
    answer.push_back(answer7); //answer[6]
    try
    {
    
        while(true) // loop to keep playing
        {
            int result = 0;
            cout << "Do you like games?\n";
            if (yes())
                result += question1;
            
            cout << "Do you like computers?\n";
            if(yes())
                result += question2;
            
            cout << "Do you like science?\n";
            if (yes())
                result += question3;
            //switch to test condition
            switch (result)
            {
                case 1:
                    cout<< answer[0] << endl;
                    break;
                case 2:
                    cout<< answer[1] << endl;
                    break;
                case 3:
                    cout<< answer[2] << endl;
                    break;
                case 4:
                    cout<< answer[3] << endl;
                    break;
                case 5:
                    cout<< answer[4] << endl;
                    break;
                case 6:
                    cout<< answer[5] << endl;
                    break;
                case 7:
                    cout<< answer[6] << endl;
                    break;
                default:
                    cout << "You must be lame for not liking computers, science, or games!!\n";
                    break;
            }
            cout << endl; // for spacing
        }
    }
    catch(runtime_error &e)
    {
        cerr << "error: " << e.what()<< endl;
        return 2;
        
    }
    return 0;
}

bool yes()
{
    string answer;
    cin >> answer;
    if(answer[0] == 'Y' || answer[0]=='y')
        return true;
    else if(answer[0] == 'N' || answer[0]=='n')
        return false;
    else
        throw runtime_error("Invalid input.");
}
