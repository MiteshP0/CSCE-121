//Mitesh Patel
//CSCE 121 - 507
//Due: March 5, 2015
//hw4pr2.cpp

//This program will calculate the roots and the residual from a quadratic equation in the form of ax^2+bx+c=0 where c is a constant. Also, this program will display a message if the root is complex. This program has special cases built in.

#include "std_lib_facilities_4a.h"
//Function prototypes
double quadratic_equation_addition(const double a, const double b, const double c);
double quadratic_equation_subtraction(const double a, const double b, const double c);
double calculate_x1_residual(const double x1, const double a, const double b, const double c);
double calculate_x2_residual(const double x2, const double a, const double b, const double c);
double simple_function(const  double a, const double b, const double c);
double calculate_x_residual(const double x, const double a, const double b, const double c);

int main()
{
    char again; // for condition to reloop
    do
    {
        try
        {
            double a, b, c;
            cout << "Enter any number for the variables a, b, and c (seperated by a space) so I can solve the quadratic equation in the form of (ax^2+bx+c=0) where c is a constant.\n"; //prompt
            cin >> a >> b >> c;
            double d=max({abs(a), abs(b), abs(c)});
            double new_a = a/d;
            double new_b = b/d;
            double new_c = c/d;
            // special cases below
            if(a == 0 && b == 0 && c==0)
            {
                cout << "x can be any number (real or complex).\n";
                
            }
            else if(a== 0 && b== 0 && c != 0)
            {
                cout << "the equation is inconsistent.\n";
                
            }
            else if (a == 0)
            {
                double x = simple_function(a,b,c);
                double residual_x = calculate_x_residual(x,a,b,c);
                cout << "x = " << x << "\t \t" << "Residual is: " << residual_x << endl;
            }
            //If new_a is 0 (due to underflow), treat it as the linear (one root) case, and solve from new_b and new_c.
            else if (new_a == 0)
            {
                double x = simple_function(new_a,new_b,new_c);
                double residual_x = calculate_x_residual(x,new_a,new_b,new_c);
                cout << "x = " << x << "\t \t" << "Residual is: " << residual_x << endl;
            }
            else if(a != 0 && b != 0 && c != 0)
            {
                double x1 = quadratic_equation_addition(a,b,c);
                double residual_x1 = calculate_x1_residual(x1,a,b,c);
                double x2 = quadratic_equation_subtraction(a,b,c);
                double residual_x2 = calculate_x2_residual(x2,a,b,c);
                if (x1==x2)
                {
                    cout << "There is a double root, and the root is: \n";
                    cout << "x = " << x1 << "\t \t" << "Residual is: " << residual_x1 << endl; // since root is equal to x2 we can use x1 or x2 to solve this part of the problem.
                }
                else
                {
                    cout << "x1 = " << x1 << "\t \t" << "Residual is: " << residual_x1 << endl;
                    cout << "x2 = " << x2 << "\t \t" << "Residual is: " << residual_x2 << endl;
                }
                
            }
            
        }
        catch(logic_error&e) //catch logic error for complex root
        {
            cerr << "error: "<< e.what() << endl;
            
        }
        cout << endl; // for spacing
        cout << "Do you want to try again with different values? (Y or N)\n";
        cin >> again;
        if(again == 'n' || again == 'N')
            exit(1); // exit if user enters n
    }while(again == 'y' || again =='Y');
    return 0;
}

//This function returns the result of the variables plugged into the quadratic equation when
//-b + sqrt(b^2-4ac)/2a
double quadratic_equation_addition(const double a, const double b, const double c)
{
    //find max and put into d, then divide user inputted a b c all divided by d
    double d=max({abs(a), abs(b), abs(c)});
    double new_a = a/d;
    double new_b = b/d;
    double new_c = c/d;
    double to_be_squared;
    double square_root; // replaced sqrt part of the problem with what hw asks for
    //If new_a is nonzero, then there are five cases:
    if(d==abs(b))
    {
        to_be_squared = 1 - 4 * (new_a) * (new_c);
        square_root = abs(b) * sqrt(to_be_squared);
    }
    else if(d==abs(a) && a>0)
    {
        to_be_squared = ((new_b) * b - 4 * c);
        square_root = sqrt(a) * sqrt(to_be_squared);
    }
    else if(d==abs(a) && a<0)
    {
        to_be_squared = (-(new_b) * b + 4 * c);
        square_root = sqrt(-a) * sqrt(to_be_squared);
    }
    else if(d==abs(c) && c > 0)
    {
        to_be_squared = ((new_b) * b - 4 * a);
        square_root = sqrt(c) * sqrt(to_be_squared);
    }
    else if(d==abs(c) && c < 0)
    {
        to_be_squared = (-(new_b) * b + 4 * a);
        square_root = sqrt(-c) * sqrt(to_be_squared);
    }
    else
    {
        to_be_squared = pow(b,2.0)-(4*a*c);
        square_root = sqrt(to_be_squared);
    }
    if(to_be_squared<0)
        throw logic_error("Roots are complex");
    double quadratic_formula_added = (-b+square_root)/(2*a);
    return quadratic_formula_added;
}

//This function returns the result of the variables plugged into the quadratic equation when
//-b - sqrt(b^2-4ac)/2a
double quadratic_equation_subtraction(const double a, const double b, const double c)
{
    double d=max({abs(a), abs(b), abs(c)});
    double new_a = a/d;
    double new_b = b/d;
    double new_c = c/d;
    double to_be_squared;
    double square_root; // replaced sqrt part of the problem with what hw asks for
    //conditions what the hw asks for
    if(d==abs(b))
    {
        to_be_squared = 1 - 4 * (new_a) * (new_c);
        square_root = abs(b) * sqrt(to_be_squared);
    }
    else if(d==abs(a) && a>0)
    {
        to_be_squared = ((new_b) * b - 4 * c);
        square_root = sqrt(a) * sqrt(to_be_squared);
    }
    else if(d==abs(a) && a<0)
    {
        to_be_squared = (-(new_b) * b + 4 * c);
        square_root = sqrt(-a) * sqrt(to_be_squared);
    }
    else if(d==abs(c) && c > 0)
    {
        to_be_squared = ((new_b) * b - 4 * a);
        square_root = sqrt(c) * sqrt(to_be_squared);
    }
    else if(d==abs(c) && c < 0)
    {
        to_be_squared = (-(new_b) * b + 4 * a);
        square_root = sqrt(-c) * sqrt(to_be_squared);
    }
    else
    {
        to_be_squared = pow(b,2.0)-(4*a*c);
        square_root = sqrt(to_be_squared);
    }
    if(to_be_squared<0)
        throw logic_error("Roots are complex");
    double quadratic_formula_subtracted = (-b-square_root)/(2*a);
    return quadratic_formula_subtracted;
}

//This function will return the residual of the value from the quadratic_equation_addition which should be 0 or very close to 0.
double calculate_x1_residual(const double x1, const double a, const double b, const double c)
{
    //equation is ax1^2 + bx1 + c
    double residual_x1 = a*(pow(x1,2.0)) + b*x1 + c;
    return residual_x1;
}

//This function will return the residual of the value from the quadratic_equation_subtraction which should be 0 or very close to 0.
double calculate_x2_residual(const double x2, const double a, const double b, const double c)
{
    //equation is ax2^2 + bx2 + c
    double residual_x2 = a*(pow(x2,2.0)) + b*x2 + c;
    return residual_x2;
}

// This function is when a is equal to 0 so therfore the function becomes simplified to bx+c = 0 and solve for x to get the root. It returns the value of result
double simple_function(const  double a, const double b, const double c)
{
    const int rvalue = 0;
    double result = (rvalue - (c))/b;
    return result;
}
// This function returns the residual from the simple_function which should be 0 or very close to 0.
double calculate_x_residual(const double x, const double a, const double b, const double c)
{
    // plug in a b and c along with x in the equation ax^2 + bx + c and it should be equal to 0 or very close to 0
    double residual_x = a*(pow(x,2.0)) + b*x + c;
    return residual_x;
}
