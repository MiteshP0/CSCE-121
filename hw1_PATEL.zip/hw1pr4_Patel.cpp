//Mitesh Patel
//CSCE 121 Section - 507
//Due: February 1, 2015
//hw1pr4.cpp

//This program will calculate how many grains and on the first, second, third, fourth square and so on.

#include "std_lib_facilities.h"
int main()
{
    int i;
    int x = 2;
    unsigned long long int present_grains = 1;
    unsigned long long int total_rice_grains = 0;
        cout<<"1st square has "<<present_grains<<" grain\n";
    for (i = 2; i<=64; i++)
    {
        total_rice_grains += present_grains;
        present_grains *= 2;
            if(i == x)
            {
                cout<< x<<" square has "<<present_grains<<" grains\n";
                x++;
            }
        
        
    }
    return 0;
}
