//Mitesh Patel
//CSCE 121 Section - 507
//Due: February 1, 2015
//hw1pr2.cpp


#include "std_lib_facilities.h"

//This program translates user inputted string number(0-19) into the spanish name. This program will only execute one number at a time.

int main()
{
    string number_name;
    cout <<"Number, please: ";
    getline(cin,number_name); // gets whole line of input
    //conditions are checking most of the possibilities of input
    // using else if statements to check each number 0-19
    if(number_name == "zero" || number_name == "ZERO" || number_name == "Zero" || number_name == "0")
    {
            cout <<"In Spanish that is cero.\n";
    
    }
    else if(number_name == "one" || number_name == "ONE" || number_name == "One" || number_name == "1")
    {
        cout <<"In Spanish that is uno.\n";
        
    }
    else if(number_name == "two" || number_name == "TWO" || number_name == "Two" || number_name == "2")
    {
        cout <<"In Spanish that is dos.\n";
        
    }
    else if(number_name == "three" || number_name == "THREE" || number_name == "Three" || number_name == "3")
    {
        cout <<"In Spanish that is tres.\n";
        
    }
    else if(number_name == "four" || number_name == "FOUR" || number_name == "Four" || number_name == "4")
    {
        cout <<"In Spanish that is cuatro.\n";
        
    }
    else if(number_name == "five" || number_name == "FIVE" || number_name == "Five" || number_name == "5")
    {
        cout <<"In Spanish that is cinco.\n";
        
    }
    else if(number_name == "six" || number_name == "SIX" || number_name == "Six" || number_name == "6")
    {
        cout <<"In Spanish that is seis.\n";
        
    }
    else if(number_name == "seven" || number_name == "SEVEN" || number_name == "Seven" || number_name == "7")
    {
        cout <<"In Spanish that is seite.\n";
        
    }
    else if(number_name == "eight" || number_name == "EIGHT" || number_name == "Eight" || number_name == "8")
    {
        cout <<"In Spanish that is ocho.\n";
        
    }
    else if(number_name == "nine" || number_name == "NINE" || number_name == "Nine" || number_name == "9")
    {
        cout <<"In Spanish that is nueve.\n";
        
    }
    else if(number_name == "ten" || number_name == "TEN" || number_name == "Ten" || number_name == "10")
    {
        cout <<"In Spanish that is diez.\n";
        
    }
    else if(number_name == "eleven" || number_name == "ELEVEN" || number_name == "Eleven" || number_name == "11")
    {
        cout <<"In Spanish that is once.\n";
        
    }
    else if(number_name == "twelve" || number_name == "TWELVE" || number_name == "Twelve" || number_name == "12")
    {
        cout <<"In Spanish that is doce.\n";
        
    }
    else if(number_name == "thirteen" || number_name == "THIRTEEN" || number_name == "Thirteen" || number_name == "13")
    {
        cout <<"In Spanish that is trece.\n";
        
    }
    else if(number_name == "fourteen" || number_name == "FOURTEEN" || number_name == "Fourteen" || number_name == "14")
    {
        cout <<"In Spanish that is catorce.\n";
        
    }
    else if(number_name == "fifteen" || number_name == "FIFTEEN" || number_name == "Fifteen" || number_name == "15")
    {
        cout <<"In Spanish that is quince.\n";
        
    }
    else if(number_name == "sixteen" || number_name == "SIXTEEN" || number_name == "Sixteen" || number_name == "16")
    {
        cout <<"In Spanish that is dieciséis.\n";
        
    }
    else if(number_name == "seventeen" || number_name == "SEVENTEEN" || number_name == "Seventeen" || number_name == "17")
    {
        cout <<"In Spanish that is diecisiete.\n";
        
    }
    else if(number_name == "eighteen" || number_name == "EIGHTEEN" || number_name == "Eighteen" || number_name == "18")
    {
        cout <<"In Spanish that is dieciocho.\n";
        
    }
    else if(number_name == "nineteen" || number_name == "NINETEEN" || number_name == "Nineteen" || number_name == "19")
    {
        cout <<"In Spanish that is diecinueve.\n";
        
    }
    else
    {
        cout << "Sorry, my vocabulary does not include " << number_name <<". Make sure you have spelled your number correctly! My vocabulary is limited to 0-19 only!\n";
    }
    
    return 0;
}
