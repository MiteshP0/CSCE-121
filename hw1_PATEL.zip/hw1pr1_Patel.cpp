//Mitesh Patel
//CSCE 121 Section - 507
//Due: February 1, 2015
//hw1pr1.cpp


#include "std_lib_facilities.h"

//This program makes a crossword puzzle for turing awards
int main()
{
    // clues for the puzzle(answers are the last name)
    cout <<"ACROSS" <<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<"DOWN\n";
    cout <<"1. Robert" <<'\t'<<'\t'<<'\t'<<'\t'<<"1. William\n";
    cout <<"3. Kenneth" <<'\t'<<'\t'<<'\t'<<'\t'<<"2. Douglas\n";
    cout <<"5. Peter" <<'\t'<<'\t'<<'\t'<<'\t'<<"4. Maurice\n";
    cout <<"6. Amir" <<'\t'<<'\t'<<'\t'<<'\t'<<'\t'<<"7. Richard\n";
    cout <<"8. Juris" <<'\t'<<'\t'<<'\t'<<'\t'<<"10. Alan\n";
    cout <<"9. Edsger" <<'\t'<<'\t'<<'\t'<<'\t'<<"11. Adi\n";
    cout <<"12. James\n";
    cout <<"13. Kristen\n";
    cout <<"14. Antony\n";

    
    cout <<"\n\n"; // used for spacing
    
    // Blank cout statements to make crossword puzzle
    cout<<"     1                                                \n";
    cout<<"   1 K A H N     2                                             \n";
    cout<<"     A           E             4                        \n";
    cout<<" 3 T H O M P S O N             W                                   \n";
    cout<<"     A           G             I                        \n";
    cout<<"   5 N A U R     E   6 P N E U L I                        \n";
    cout<<"                 L       7     K                       \n";
    cout<<"                 B       H     E                       \n";
    cout<<"             8 H A R T M A N I S                                    \n";
    cout<<"             10  R       M                             \n";
    cout<<"     9 D I J K S T R A   M   11                         \n";
    cout<<"             A           I   S                         \n";
    cout<<"    12 G R A Y           N   H                         \n";
    cout<<"                  13 N Y G A A R D                           \n";
    cout<<"                             M                        \n";
    cout<<"                             I                        \n";
    cout<<"                    14 H A O R E                        \n";
    cout<<"                                                     \n";
    
    return 0;
    
}