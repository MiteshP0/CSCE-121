//Mitesh Patel
//CSCE 121 Section - 507
//Due: February 1, 2015
//hw1pr3.cpp

//This programs calculates the amount of squares needed to give inventor 1000, 1000000, and 100000000 rice gains.

#include "std_lib_facilities.h"


int i = 0; // global variable so the seperate functions have access to it.
// global constants so the seperate functions have access to it
const int one_thousand = 1000;
const int one_million = 1000000;
const int one_billion = 1000000000;
// function prototypes
void calculate_thousand();
void calculate_million();
void calculate_billion();

int main()
{
    calculate_thousand();
    calculate_million();
    calculate_billion();
    return 0;
}

void calculate_thousand()
{
    int present_grains_thousand = 1;
    int total_rice_grains_thousand = 0;
    for (i = 0; total_rice_grains_thousand <= one_thousand; ++i)
    {
        total_rice_grains_thousand += present_grains_thousand;
        present_grains_thousand *= 2;
        
    }
    cout << i <<" squares for 1 thousand\n";
}

void calculate_million()
{
    int present_grains_million = 1;
    int total_rice_grains_million = 0;
    for (i = 0; total_rice_grains_million <= one_million; ++i)
    {
        total_rice_grains_million += present_grains_million;
        present_grains_million *= 2;
        
    }
    cout << i <<" squares for 1 million\n";
}

void calculate_billion()
{
    int present_grains_billion = 1;
    int total_rice_grains_billion = 0; // accumulator for total grains reaching billion
    for (i = 0; total_rice_grains_billion <= one_billion; ++i)
    {
        total_rice_grains_billion += present_grains_billion;
        present_grains_billion *= 2;
        
    }
    cout << i <<" squares for 1 billion\n";
}

